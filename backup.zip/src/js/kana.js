import { DEBUG } from './config.js';
import { fetchFile } from './fs.js';
class KeyManager {
    static key = {
        BACKSPACE: 'Backspace',
        DELETE: 'Delete',
        C: 'KeyC',
        V: 'KeyV',
    };
    static keys = {};
    static addKey(uid, condition) {
        KeyManager.keys[uid] = condition;
        return KeyManager;
    }
    static removeKey(uid) {
        const { [uid]: _, ...newKeys } = KeyManager.keys;
        KeyManager.keys = newKeys;
        return KeyManager;
    }
    static isKey(uid, event) {
        return KeyManager.keys[uid](event);
    }
}
class KanaLoader {
    separator = '-';
    defaultFilepath = './../data/unicode.json';
    static file = null;
    async loadKana({ filepath, key, asMap, descriptionsFilter, groupsFilter, inputsFilter, combinationsFilter }) {
        const descriptions = descriptionsFilter || [];
        const groups = groupsFilter || [];
        const inputs = inputsFilter || [];
        const combinations = combinationsFilter || [];
        if (KanaLoader.file === null)
            KanaLoader.file = await fetchFile(filepath || this.defaultFilepath);
        const kana = KanaLoader.file[key] ?? {};
        DEBUG && console.debug('Loaded file', KanaLoader.file);
        const included = this.filterForInclusion(kana, { descriptions, groups, inputs, combinations });
        const excluded = this.filterForExclusion(included, { descriptions, groups, inputs, combinations });
        DEBUG && console.debug('Filtered', key, excluded);
        if (!asMap)
            return excluded;
        return this.toMap(excluded);
    }
    filterStringProperty = (prop, target) => !target.length || target.includes(prop);
    filterArrayProperty = (prop, target) => !target.length || prop.some((sub) => target.includes(sub));
    inclusion = (arr) => arr.filter(item => !item.startsWith(this.separator));
    exclusion = (arr) => arr.filter(item => item.startsWith(this.separator)).map(item => item.slice(1));
    filterForInclusion(data, { descriptions, groups, inputs, combinations }) {
        return Object.entries(data).reduce((result, [key, value]) => this.filterStringProperty(value.description, this.inclusion(descriptions)) &&
            this.filterStringProperty(value.group, this.inclusion(groups)) &&
            this.filterArrayProperty(value.inputs, this.inclusion(inputs)) &&
            this.filterArrayProperty(value.combination, this.inclusion(combinations))
            ? { ...result, [key]: value }
            : result, {});
    }
    filterForExclusion(data, { descriptions, groups, inputs, combinations }) {
        return Object.entries(data).reduce((result, [key, value]) => this.filterStringProperty(value.description, this.exclusion(descriptions)) &&
            this.filterStringProperty(value.group, this.exclusion(groups)) &&
            this.filterArrayProperty(value.inputs, this.exclusion(inputs)) &&
            this.filterArrayProperty(value.combination, this.exclusion(combinations))
            ? result
            : { ...result, [key]: value }, {});
    }
    toMap(data) {
        return Object.entries(data).reduce((result, [key, value]) => {
            value.inputs.forEach((input) => result[input] = key);
            return result;
        }, {});
    }
}
class Kana {
    static hiraganaMap = {};
    static katakanaMap = {};
    static loader = null;
    static get HIRAGANA() {
        return Kana.hiraganaMap;
    }
    static get KATAKANA() {
        return Kana.katakanaMap;
    }
    static get HIRAGANA_CODES() {
        return [...new Set(Object.values(Kana.hiraganaMap))];
    }
    static get KATAKANA_CODES() {
        return [...new Set(Object.values(Kana.katakanaMap))];
    }
    static get HIRAGANA_INPUTS() {
        return [...new Set(Object.keys(Kana.hiraganaMap))];
    }
    static get KATAKANA_INPUTS() {
        return [...new Set(Object.keys(Kana.katakanaMap))];
    }
    static get ALL_HIRAGANA_TEST() {
        return [
            'a', 'i', 'u', 'e', 'o', 'n',
            'ka', 'ki', 'ku', 'ke', 'ko',
            'ga', 'gi', 'gu', 'ge', 'go',
            'sa', 'shi', 'su', 'se', 'so',
            'za', 'ji', 'zu', 'ze', 'zo',
            'ta', 'chi', 'tsu', 'te', 'to',
            'da', 'de', 'do',
            'na', 'ni', 'nu', 'ne', 'no',
            'ha', 'hi', 'fu', 'he', 'ho',
            'ba', 'bi', 'bu', 'be', 'bo',
            'pa', 'pi', 'pu', 'pe', 'po',
            'ma', 'mi', 'mu', 'me', 'mo',
            'ya', 'yu', 'yo',
            'ra', 'ri', 'ru', 're', 'ro',
            'wa', 'wo',
            'kya', 'kyu', 'kyo',
            'gya', 'gyu', 'gyo',
            'sha', 'shu', 'sho',
            'ja', 'ju', 'jo',
            'cha', 'chu', 'cho',
            'nya', 'nyu', 'nyo',
            'hya', 'hyu', 'hyo',
            'bya', 'byu', 'byo',
            'pya', 'pyu', 'pyo',
            'mya', 'myu', 'myo',
            'rya', 'ryu', 'ryo',
        ];
    }
    static hiragana(key) {
        const value = Kana.hiraganaMap[key];
        return value === undefined ? null : value;
    }
    static katakana(key) {
        const value = Kana.katakanaMap[key];
        return value === undefined ? null : value;
    }
    static async loadHiragana(args) {
        Kana.hiraganaMap = await Kana.loadKana({ ...args, key: 'hiragana' });
    }
    static async loadKatakana(args) {
        Kana.katakanaMap = await Kana.loadKana({ ...args, key: 'katakana' });
    }
    static async loadKana(args) {
        if (Kana.loader === null)
            Kana.loader = new KanaLoader();
        return await Kana.loader.loadKana(args);
    }
}
class KanaChar {
    input = '';
    output = '';
    constructor(value) {
        if (value !== undefined)
            this.append(value);
    }
    get length() {
        return this.isValid ? this.output.length : this.input.length;
    }
    get romaji() {
        return this.input;
    }
    get value() {
        return this.isValid ? this.output : this.input;
    }
    get isEmpty() {
        return this.input === '';
    }
    get isValid() {
        return this.output !== '';
    }
    get isFinal() {
        return this.isValid && !this.isN;
    }
    get isN() {
        return this.input === 'n';
    }
    static isVowel(value) {
        return ['a', 'i', 'u', 'e', 'o'].includes(value);
    }
    static isRomaji(char) {
        return /[a-zA-Z]/.test(char);
    }
    static hex2symbol(value) {
        return String.fromCodePoint(parseInt(value, 16));
    }
    append(char) {
        if (char === '')
            return;
        if (!this.isValid)
            this.input += char;
        else if (this.isN && (KanaChar.isVowel(char) || char === 'y'))
            this.input += char;
        else
            return;
        this.validate();
    }
    pop() {
        if (this.input.length < 1)
            return '';
        let char = this.input.slice(-1);
        this.input = this.input.slice(0, -1);
        this.validate();
        return char;
    }
    validate() {
        if (this.isDoubleConsonant) {
            const [a, b] = [this.getChar('xtsu'), this.getChar(this.input.slice(1))];
            if (a === null || b === null) {
                return false;
            }
            this.output = KanaChar.hex2symbol(a)
                + KanaChar.hex2symbol(b);
            return true;
        }
        let youon = this.isYouon;
        if (youon !== null) {
            const [a, b] = [this.getChar(youon[0]), this.getChar(youon[1])];
            if (a === null || b === null) {
                return false;
            }
            this.output = KanaChar.hex2symbol(a)
                + KanaChar.hex2symbol(b);
            return true;
        }
        let double_consonant_and_youon = this.isDoubleConsonantAndYouon;
        if (double_consonant_and_youon !== null) {
            const [a, b, c] = [this.getChar(double_consonant_and_youon[0]), this.getChar(double_consonant_and_youon[1]), this.getChar(double_consonant_and_youon[2])];
            if (a === null || b === null || c == null) {
                return false;
            }
            this.output = KanaChar.hex2symbol(a)
                + KanaChar.hex2symbol(b)
                + KanaChar.hex2symbol(c);
            return true;
        }
        let raw_code = this.getChar(this.input);
        if (raw_code !== null) {
            this.output = KanaChar.hex2symbol(raw_code);
            return true;
        }
        this.output = '';
        return false;
    }
}
class HiraganaChar extends KanaChar {
    get isDoubleConsonant() {
        return this.input.length > 2 &&
            this.input.charAt(0) === this.input.charAt(1) &&
            this.getChar(this.input.slice(1)) !== null;
    }
    get isYouon() {
        const consonants = ['k', 'n', 'h', 'm', 'r', 'g', 'b', 'p'];
        const yayuyo = ['ya', 'yu', 'yo'];
        const shch = ['sh', 'ch'];
        const auo = ['a', 'u', 'o'];
        if (this.input.length === 3 &&
            consonants.includes(this.input.charAt(0)) &&
            yayuyo.includes(this.input.slice(1))) {
            return [this.input.charAt(0) + 'i', 'x' + this.input.slice(1)];
        }
        else if (this.input.length === 3 &&
            shch.includes(this.input.slice(0, 2)) &&
            auo.includes(this.input.charAt(2))) {
            return [this.input.slice(0, 2) + 'i', 'xy' + this.input.charAt(2)];
        }
        else if (this.input.length === 2 &&
            'j' == this.input.charAt(0) &&
            auo.includes(this.input.charAt(1))) {
            return ['ji', 'xy' + this.input.charAt(1)];
        }
        return null;
    }
    get isDoubleConsonantAndYouon() {
        if (this.input.charAt(0) !== this.input.charAt(1))
            return null;
        const youon = new HiraganaChar(this.input.slice(1));
        const youon_tuple = youon.isYouon;
        if (youon_tuple !== null)
            return ['xtsu', ...youon_tuple];
        return null;
    }
    getChar(key) {
        return Kana.hiragana(key);
    }
}
export { KeyManager, Kana, KanaLoader, HiraganaChar };
