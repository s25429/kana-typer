import { DEBUG } from './config.js';
import preload from './preload.js';
import { KeyManager, Kana, HiraganaChar } from './kana.js';
await preload();
switch (getScriptVersion()) {
    case 1:
        ver1();
        break;
    case 2:
        ver2();
        break;
    default: ver2();
}
function ver1() {
    const source = document.querySelector('#kana-container #source');
    const target = document.querySelector('#kana-container #target');
    const panel = document.querySelector('#kana-container #panel');
    const startButton = panel.querySelector('button.start');
    const stats = panel.querySelector('.stats');
    const timer = document.querySelector('#kana-container .timer');
    let sourceText = [];
    let targetText = [];
    let timeLeft = 60;
    let timerInterval = null;
    let statistics;
    startButton.addEventListener('click', start);
    function stop() {
        panel.style.display = 'block';
        timer.style.visibility = 'hidden';
        source.style.display = 'none';
        target.removeEventListener('keydown', targetKeyDownEventListener);
        if (timerInterval) {
            clearInterval(timerInterval);
            timerInterval = null;
        }
        for (let i = 0; i < targetText.length; i++) {
            if (targetText[i].value === sourceText[i].value)
                statistics.correctCharacters++;
            else
                statistics.incorrectCharacters++;
            statistics.charactersPerMinute++;
        }
        statistics.characterAccuracy = parseFloat((statistics.correctCharacters * 100 / statistics.charactersPerMinute).toFixed(1));
        stats.innerHTML = `
            <li>Characters Per Minute: ${statistics.charactersPerMinute}</li>
            <li>Character Accuracy: ${statistics.characterAccuracy}%</li>
            <li>Correct Characters: ${statistics.correctCharacters}</li>
            <li>Incorrect Characters: ${statistics.incorrectCharacters}</li>
            <li>Time Elapsed: ${statistics.timeElapsed}s</li>
            <li>Kana Type: ${statistics.kanaType}</li>
        `;
    }
    function start() {
        sourceText = generateRandomHiragana({ max: 200 });
        targetText.length = 0;
        timeLeft = 60;
        panel.style.display = 'none';
        timer.style.visibility = 'visible';
        source.style.display = 'block';
        target.innerHTML = '';
        timer.innerHTML = `${timeLeft}`;
        updateSourceKana();
        target.addEventListener('keydown', targetKeyDownEventListener);
        if (!timerInterval)
            timerInterval = setInterval(updateTimer, 1000);
        statistics = {
            charactersPerMinute: 0,
            characterAccuracy: 0,
            kanaType: 'hiragana',
            correctCharacters: 0,
            incorrectCharacters: 0,
            timeElapsed: 0,
        };
    }
    function targetKeyDownEventListener(event) {
        DEBUG && console.debug(event, '\n', targetText);
        if (KeyManager.isKey('bs', event)) {
            if (targetText.length === 0)
                return;
            targetText[targetText.length - 1].pop();
            if (targetText[targetText.length - 1].isEmpty) {
                targetText.pop();
            }
        }
        else if (KeyManager.isKey('dl', event)) {
            if (targetText.length === 0)
                return;
            target.innerHTML = '';
            targetText.length = 0;
        }
        else if (KeyManager.isKey('ctrl+c', event)) {
            const range = document.createRange();
            range.selectNode(target);
            window.getSelection()?.removeAllRanges();
            window.getSelection()?.addRange(range);
            try {
                document.execCommand('copy');
                console.log('Text copied to clipboard:', target.textContent);
            }
            catch (error) {
                console.error('Copy failed:', error);
            }
        }
        else if (KeyManager.isKey('ctrl+v', event)) {
            stop();
        }
        else if (KeyManager.isKey('non-function-keys', event)) {
            let key = event.key.toLowerCase();
            if (targetText.length === 0 || targetText[targetText.length - 1].isFinal) {
                targetText.push(new HiraganaChar(key));
            }
            else {
                targetText[targetText.length - 1].append(key);
            }
        }
        target.innerHTML = '';
        for (let i = 0; i < targetText.length; i++) {
            const char = targetText[i];
            if (HiraganaChar.isRomaji(char.value)) {
                target.innerHTML += char.value;
                continue;
            }
            const color = char.value === sourceText[i].value ? 'lime' : 'red';
            target.innerHTML += `<span style="color:${color}">${char.value}</span>`;
        }
        let position = 0;
        targetText.forEach((char) => {
            if (char.isFinal)
                position++;
            else
                return;
        });
        updateSourceKana(position);
    }
    function updateTimer() {
        if (--timeLeft < 0) {
            stop();
            timer.innerHTML = '_';
            return;
        }
        else {
            statistics.timeElapsed++;
        }
        let attr = '';
        if (timeLeft < 10)
            attr = 'style="color: red;"';
        else if (timeLeft < 30)
            attr = 'style="color: yellow;"';
        timer.innerHTML = `<span ${attr}>${timeLeft}</span>`;
    }
    function updateSourceKana(position = 0) {
        source.innerHTML = sourceText.map((char, index) => {
            if (index > position)
                return `<span style="color: gray">${char.value}</span>`;
            else if (index === position)
                return `<span>${char.value}</span>`;
            else if (char.value === targetText[index].value)
                return `<span style="color: lime">${char.value}</span>`;
            else
                return `<span style="color: red">${char.value}</span>`;
        }).join('');
    }
    function generateRandomHiragana({ min, max } = {}) {
        const romajiChars = Kana.ALL_HIRAGANA_TEST;
        if (romajiChars.length === 0) {
            console.error(`Unable to generate text with empty hiragana map`);
            return [];
        }
        let hiragana = [];
        for (let i = (min ?? 1); i < (max ?? 2) + 1; i++) {
            let rand = Math.floor(Math.random() * romajiChars.length);
            hiragana.push(new HiraganaChar(romajiChars[rand]));
        }
        return hiragana;
    }
}
function ver2() {
    const textarea = document.querySelector('#kana-container .typer');
    const genEl = document.querySelector('#kana-container .text');
    const text = [];
    const generated = generateRandomHiragana();
    const fontWidth = getKanaFontWidth();
    let index = 0;
    let offset = 0;
    let direction = 0;
    textarea.addEventListener('keydown', (event) => {
        DEBUG && console.log(event, '\n', text, '\n', generated);
        direction = 0;
        console.log(index, text.length - 1);
        if (KeyManager.isKey('bs', event)) {
            if (text.length === 0)
                return;
            text[text.length - 1].pop();
            if (text[text.length - 1].isEmpty) {
                text.pop();
                direction = -1;
            }
            index = text.length - 1;
            if (index < 0)
                index = 0;
        }
        else if (KeyManager.isKey('ctrl-c', event)) {
            if (text.length === 0)
                return;
            textarea.innerHTML = '';
            text.length = 0;
        }
        else if (KeyManager.isKey('non-function-keys', event)) {
            let key = event.key.toLowerCase();
            if (text.length === 0 || text[text.length - 1].isFinal) {
                if (text.length === 0)
                    index = 0;
                else
                    index++;
                text.push(new HiraganaChar(key));
            }
            else {
                text[text.length - 1].append(key);
            }
            direction = 1;
        }
        let newTextarea = '';
        let char = text[index];
        let orig = generated[index];
        if (char !== undefined) {
            if (char.isFinal || char.isValid && orig.isN) {
                textarea.innerHTML = 'type...';
                const el = genEl.children[index];
                if (char.value === orig.value) {
                    el.style.color = 'green';
                }
                else {
                    el.style.color = 'red';
                }
                if (direction !== 0) {
                    offset += el.offsetWidth / fontWidth * direction;
                    genEl.style.cssText = `
                        transform: translateX(calc(
                            var(--initial-pos) - var(--font-size) * ${offset}
                        )); 
                        transition: transform .1s linear;`;
                }
            }
            else {
                textarea.innerHTML = char.value;
            }
        }
        else {
            textarea.innerHTML = 'type...';
        }
    });
    function generateRandomHiragana() {
        const romajiChars = Kana.ALL_HIRAGANA_TEST;
        if (romajiChars.length === 0) {
            console.error(`Unable to generate text with empty hiragana map`);
            return [];
        }
        let hiragana = [];
        let text = '';
        const wordSize = { min: 8, max: 20 };
        const el = document.querySelector('#kana-container .text');
        for (let i = wordSize.min; i < wordSize.max + 1; i++) {
            let rand = Math.floor(Math.random() * romajiChars.length);
            let char = new HiraganaChar(romajiChars[rand]);
            hiragana.push(char);
            text += char.isFinal ? `<span>${char.value}</span>` : '';
        }
        el.innerHTML = text;
        return hiragana;
    }
    function getKanaFontWidth() {
        const fontSize = 4;
        const fontFamily = 'Noto Sans JP';
        const char = HiraganaChar.hex2symbol(Kana.hiragana('a') ?? '61');
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        context.font = `${fontSize}rem ${fontFamily}`;
        return context.measureText(char).width;
    }
}
function getScriptVersion() {
    const scriptUrl = new URL(import.meta.url);
    const queryParams = new URLSearchParams(scriptUrl.search);
    return parseInt(queryParams.get('version') ?? '0');
}
